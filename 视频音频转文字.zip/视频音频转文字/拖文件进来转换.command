#!/bin/bash
# 双击运行：把任意位置的文件或文件夹拖进窗口，回车即开始转换
cd "$(dirname "$0")"
clear
echo "=========================================="
echo "   视频音频转文字 · 拖放模式"
echo "=========================================="
echo
echo "把音频/视频文件（或整个文件夹）拖进这个窗口，可以一次拖多个，"
echo "然后按 回车 开始。结果保存在本工具的「输出」文件夹里。"
echo
read -r -p "> " line
# 终端里拖进来的路径会把空格等特殊字符用反斜杠转义，这里还原成真实路径
eval "paths=($line)" 2>/dev/null || { echo "路径无法识别，请重试。"; read -n 1 -s; exit 1; }
if [ ${#paths[@]} -eq 0 ]; then echo "没有拖入文件。"; read -n 1 -s -r -p "按任意键关闭…"; exit 0; fi
bash "./app/transcribe.sh" "${paths[@]}"
open "./输出" 2>/dev/null
echo
read -n 1 -s -r -p "按任意键关闭窗口…"
echo
