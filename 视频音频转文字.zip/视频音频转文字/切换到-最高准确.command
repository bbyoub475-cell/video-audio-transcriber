#!/bin/bash
# 双击运行：把 设置.txt 切换到「最高准确」模式（语言、输出格式、提示词等其它设置保持不变）
cd "$(dirname "$0")"
CONF="./设置.txt"
setv() { # 键 值：改写 设置.txt 里的一行，没有就追加
  if grep -q "^$1=" "$CONF"; then
    sed -i '' "s|^$1=.*|$1=\"$2\"|" "$CONF"
  else
    printf '%s="%s"\n' "$1" "$2" >> "$CONF"
  fi
}
clear
[ -f "$CONF" ] || { echo "找不到 设置.txt"; read -n 1 -s; exit 1; }
if [ ! -f "./app/models/ggml-large-v3.bin" ]; then
  echo "✗ 缺少 app/models/ggml-large-v3.bin（最高准确模式用的大模型，约 3GB）。"
  echo "  下载方法见「使用教程.md」第 6 节。设置没有改动。"
  read -n 1 -s -r -p "按任意键关闭窗口…"; exit 1
fi
setv MODE "最高准确"
setv MODEL "ggml-large-v3.bin"
setv USE_VAD "no"
setv BEAM_SIZE "8"
setv INDEPENDENT_SEGMENTS "yes"
echo "=========================================="
echo "   ✓ 已切换到：最高准确 模式"
echo "=========================================="
echo
echo " · 模型：large-v3 完整版（最准）"
echo " · 不跳过任何片段（静音检测关闭），整段逐句识别"
echo " · 搜索宽度开到最大（8），每段独立识别，防止漏段和重复"
echo " · 速度比性价比模式慢几倍，适合扒歌词、电影字幕、复杂的长通话"
echo
echo "之后双击「开始转换.command」就按这个模式转。"
echo "「输入」里以前用另一个模式转过的文件，会用新模式重新转一遍并覆盖旧结果。"
echo
read -n 1 -s -r -p "按任意键关闭窗口…"
echo
