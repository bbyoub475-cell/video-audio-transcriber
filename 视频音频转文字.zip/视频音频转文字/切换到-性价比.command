#!/bin/bash
# 双击运行：把 设置.txt 切换到「性价比」模式（语言、输出格式、提示词等其它设置保持不变）
cd "$(dirname "$0")"
CONF="./设置.txt"
setv() { # 键 值：改写 设置.txt 里的一行，没有就追加
  if grep -q "^$1=" "$CONF"; then
    sed -i '' "s|^$1=.*|$1=\"$2\"|" "$CONF"
  else
    printf '%s="%s"\n' "$1" "$2" >> "$CONF"
  fi
}
clear
[ -f "$CONF" ] || { echo "找不到 设置.txt"; read -n 1 -s; exit 1; }
setv MODE "性价比"
setv MODEL "ggml-large-v3-turbo.bin"
setv USE_VAD "yes"
setv BEAM_SIZE ""
setv INDEPENDENT_SEGMENTS "no"
echo "=========================================="
echo "   ✓ 已切换到：性价比 模式"
echo "=========================================="
echo
echo " · 模型：large-v3-turbo（又快又准）"
echo " · 自动跳过没人说话的片段（误判时会自动整段重转）"
echo " · 适合日常：会议、课程、访谈、普通视频，大批量处理"
echo
echo "之后双击「开始转换.command」就按这个模式转。"
echo "「输入」里以前用另一个模式转过的文件，会用新模式重新转一遍并覆盖旧结果。"
echo
read -n 1 -s -r -p "按任意键关闭窗口…"
echo
