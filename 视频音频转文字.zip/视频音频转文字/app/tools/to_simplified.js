// 中文结果整理：繁体→简体、中文旁边的半角标点→全角
// 只用 macOS 自带的 ICU 转换，无需安装任何东西
// 用法：osascript -l JavaScript to_simplified.js 文件1 [文件2 ...]
ObjC.import('Foundation');
function run(argv) {
  var map = { ',': '，', '?': '？', '!': '！', ';': '；', ':': '：' };
  argv.forEach(function (p) {
    var s = $.NSString.stringWithContentsOfFileEncodingError(p, $.NSUTF8StringEncoding, null);
    if (s.isNil()) return;
    var t = s.stringByApplyingTransformReverse('Traditional-Simplified', false);
    if (t.isNil()) return;
    var js = t.js.replace(/([㐀-鿿])[ \t]*([,?!;:])[ \t]*/g, function (m, c, q) { return c + map[q]; });
    $(js).writeToFileAtomicallyEncodingError(p, true, $.NSUTF8StringEncoding, null);
  });
}
