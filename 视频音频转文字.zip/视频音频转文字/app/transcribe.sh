#!/bin/bash
# ==========================================================
#  视频音频转文字 · 核心脚本
#  用法： app/transcribe.sh  文件或文件夹 [更多文件或文件夹 ...]
#  不带参数时处理「输入」文件夹里的全部文件。
#  只用到本文件夹内的程序 + macOS 自带组件，不依赖 Homebrew / Python。
# ==========================================================

set -u
export LC_ALL=en_US.UTF-8 2>/dev/null

APP_DIR="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(dirname "$APP_DIR")"
BIN="$APP_DIR/bin"
MODELS="$APP_DIR/models"
IN_ROOT="$ROOT/输入"
OUT_ROOT="$ROOT/输出"
LOG_DIR="$APP_DIR/logs"
mkdir -p "$IN_ROOT" "$OUT_ROOT" "$LOG_DIR"
LOG="$LOG_DIR/$(date +%Y%m%d-%H%M%S).log"

# ---------- 默认设置（可被 设置.txt 覆盖） ----------
LANGUAGE="auto"; SIMPLIFIED_CHINESE="yes"; FORMATS="txt srt"
MODEL="ggml-large-v3-turbo.bin"; USE_VAD="yes"; EXISTING="skip"
MOVE_DONE="no"; THREADS=""; PROMPT=""; MODE=""; BEAM_SIZE=""; INDEPENDENT_SEGMENTS="no"
if [ -f "$ROOT/设置.txt" ]; then
  # 去掉 Windows 换行后再读取
  eval "$(tr -d '\r' < "$ROOT/设置.txt")"
fi

c_red=$'\033[31m'; c_grn=$'\033[32m'; c_ylw=$'\033[33m'; c_cyn=$'\033[36m'; c_dim=$'\033[2m'; c_off=$'\033[0m'
say()  { printf '%s\n' "$*"; printf '%s\n' "$*" | sed $'s/\033\\[[0-9;]*m//g' >> "$LOG"; }
die()  { say "${c_red}✗ $*${c_off}"; exit 1; }

# ---------- 环境检查 ----------
[ "$(uname -s)" = "Darwin" ] || die "本工具只能在 macOS 上运行。"
if [ "$(uname -m)" != "arm64" ] && [ "$(sysctl -n sysctl.proc_translated 2>/dev/null)" != "1" ]; then
  die "这台 Mac 不是 Apple 芯片（M1/M2/M3/M4/M5…），本文件夹里的程序无法运行。见「使用教程.md」第 8 节。"
fi
# 拷贝/下载后 macOS 可能加上「隔离」标记或丢失执行权限，这里自动修复（只作用于本文件夹）
xattr -dr com.apple.quarantine "$ROOT" 2>/dev/null
chmod +x "$BIN/ffmpeg" "$BIN/whisper-cli" "$ROOT"/*.command "$APP_DIR"/*.sh 2>/dev/null

FFMPEG="$BIN/ffmpeg"; WHISPER="$BIN/whisper-cli"
[ -x "$FFMPEG" ]  || die "找不到 app/bin/ffmpeg，文件夹可能不完整。"
[ -x "$WHISPER" ] || die "找不到 app/bin/whisper-cli，文件夹可能不完整。"
MODEL_PATH="$MODELS/$MODEL"
if [ ! -f "$MODEL_PATH" ] && [ -f "$MODELS/ggml-large-v3-turbo.bin" ] && [ "$MODEL" != "ggml-large-v3-turbo.bin" ]; then
  say "${c_ylw}! 找不到模型 $MODEL，暂时改用 ggml-large-v3-turbo.bin${c_off}"
  MODEL="ggml-large-v3-turbo.bin"; MODEL_PATH="$MODELS/$MODEL"
fi
[ -f "$MODEL_PATH" ] || die "找不到模型 app/models/$MODEL（请检查 设置.txt 里的 MODEL）。"
VAD_MODEL="$MODELS/ggml-silero-v5.1.2.bin"

[ -z "$THREADS" ] && THREADS="$(sysctl -n hw.perflevel0.physicalcpu 2>/dev/null || echo 4)"

EXTS=" mp3 wav m4a aac flac ogg oga opus wma amr aiff aif caf mp4 m4v mov mkv webm avi flv wmv ts mts m2ts 3gp mpg mpeg vob "

# ---------- 收集要处理的文件 ----------
LIST="$(mktemp -t vtt_list)"
add_file() {
  local f="$1" ext
  ext="$(printf '%s' "${f##*.}" | tr '[:upper:]' '[:lower:]')"
  case "$EXTS" in *" $ext "*) printf '%s\0' "$f" >> "$LIST" ;; esac
}
[ $# -eq 0 ] && set -- "$IN_ROOT"
for arg in "$@"; do
  if [ -d "$arg" ]; then
    while IFS= read -r -d '' f; do add_file "$f"; done < <(
      find "$arg" -type f ! -name '.*' ! -path '*/已完成/*' -print0 | sort -z)
  elif [ -f "$arg" ]; then
    add_file "$arg"
  else
    say "${c_ylw}! 跳过（不存在）：$arg${c_off}"
  fi
done

TOTAL=$(tr -cd '\0' < "$LIST" | wc -c | tr -d ' ')
if [ "$TOTAL" -eq 0 ]; then
  say "${c_ylw}没有找到可转换的音频/视频文件。${c_off}"
  say "把文件放进「输入」文件夹后再运行，或把文件拖进窗口。"
  rm -f "$LIST"; exit 0
fi

[ -n "$MODE" ] && say "${c_cyn}当前模式：$MODE${c_off}"
say "${c_cyn}共 $TOTAL 个文件 · 模型 $MODEL · 语言 $LANGUAGE · 输出 $FORMATS${c_off}"
say "${c_dim}日志：$LOG${c_off}"

fmt_args=()
for f in $FORMATS; do fmt_args+=("-o$f"); done
first_fmt="${FORMATS%% *}"

TMPDIR_RUN="$(mktemp -d -t vtt)"
trap 'rm -rf "$TMPDIR_RUN" "$LIST"' EXIT

n=0; ok=0; skipped=0; failed=0; START_ALL=$(date +%s)
while IFS= read -r -d '' src; do
  n=$((n+1))
  name="$(basename "$src")"; base="${name%.*}"
  # 「输入」里的子文件夹结构会照搬到「输出」
  case "$src" in
    "$IN_ROOT"/*) rel="$(dirname "${src#"$IN_ROOT"/}")"; [ "$rel" = "." ] && rel="" ;;
    *) rel="" ;;
  esac
  outdir="$OUT_ROOT${rel:+/$rel}"; mkdir -p "$outdir"
  outbase="$outdir/$base"

  say ""
  say "${c_cyn}[$n/$TOTAL] $name${c_off}"
  # 记录每个结果是用哪个模式转的：换了模式后同一个文件会自动重转
  modef="$outdir/.$base.mode"
  lastmode="$(cat "$modef" 2>/dev/null)"
  if [ "$EXISTING" = "skip" ] && [ -f "$outbase.$first_fmt" ] && [ "$lastmode" = "$MODE" ]; then
    say "${c_dim}  已用当前模式转过，跳过（要重转请在 设置.txt 里把 EXISTING 改成 redo）${c_off}"
    skipped=$((skipped+1)); continue
  fi

  # 1) 提取音频 → 16kHz 单声道 wav
  wav="$TMPDIR_RUN/audio.wav"
  if ! "$FFMPEG" -nostdin -hide_banner -loglevel error -y -i "$src" -vn -sn -dn \
        -ac 1 -ar 16000 -c:a pcm_s16le "$wav" 2>>"$LOG"; then
    say "${c_red}  ✗ 读取失败（文件损坏或没有音轨），详见日志${c_off}"; failed=$((failed+1)); continue
  fi
  bytes=$(stat -f %z "$wav"); secs=$(( (bytes-44) / 32000 ))
  if [ "$secs" -lt 1 ]; then
    say "${c_red}  ✗ 没有可用的声音${c_off}"; failed=$((failed+1)); continue
  fi
  say "${c_dim}  时长 $((secs/3600))小时$((secs%3600/60))分$((secs%60))秒${c_off}"

  # 2) 确定语言
  lang="$LANGUAGE"
  if [ "$lang" = "auto" ]; then
    lang="$("$WHISPER" -m "$MODEL_PATH" -f "$wav" -dl -t "$THREADS" 2>&1 \
            | sed -n 's/.*auto-detected language: \([a-z]*\).*/\1/p' | head -1)"
    [ -z "$lang" ] && lang="auto"
    say "${c_dim}  识别到语言：$lang${c_off}"
  fi

  # 3) 提示词（中文时引导输出简体 + 标点）
  p="$PROMPT"
  if [ "$lang" = "zh" ] && [ "$SIMPLIFIED_CHINESE" = "yes" ]; then
    p="以下是普通话的句子，使用简体中文，带标点。${p}"
  fi
  args=(-m "$MODEL_PATH" -f "$wav" -l "$lang" -t "$THREADS" -of "$outbase" "${fmt_args[@]}")
  [ -n "$BEAM_SIZE" ] && args+=(-bs "$BEAM_SIZE" -bo "$BEAM_SIZE")
  [ "$INDEPENDENT_SEGMENTS" = "yes" ] && args+=(-mc 0)
  [ -n "$p" ] && args+=(--prompt "$p")
  if [ "$USE_VAD" = "yes" ] && [ -f "$VAD_MODEL" ]; then
    args+=(--vad -vm "$VAD_MODEL")
  fi

  # 4) 转写（屏幕上实时显示识别出的文字）
  t0=$(date +%s)
  errf="$TMPDIR_RUN/whisper.err"
  "$WHISPER" "${args[@]}" 2>"$errf" | tee -a "$LOG"
  rc=${PIPESTATUS[0]}
  cat "$errf" >> "$LOG"
  # 静音检测如果砍掉了一半以上的声音，多半是误判（唱歌、背景音乐、音量很小的录音），
  # 这时关掉静音检测整段重转，宁可慢一点也不丢内容
  cut="$(sed -n 's/.*Reduced audio from .*(\([0-9]*\)[.0-9]*% reduction).*/\1/p' "$errf" | head -1)"
  if [ "$USE_VAD" = "yes" ] && [ "$rc" -eq 0 ] && [ -n "$cut" ] && [ "$cut" -ge 50 ]; then
    say "${c_ylw}  静音检测跳过了 ${cut}% 的内容，可能是音乐或小音量录音，改为整段重新识别…${c_off}"
    args2=(-m "$MODEL_PATH" -f "$wav" -l "$lang" -t "$THREADS" -of "$outbase" "${fmt_args[@]}")
    [ -n "$BEAM_SIZE" ] && args2+=(-bs "$BEAM_SIZE" -bo "$BEAM_SIZE")
    [ "$INDEPENDENT_SEGMENTS" = "yes" ] && args2+=(-mc 0)
    [ -n "$p" ] && args2+=(--prompt "$p")
    "$WHISPER" "${args2[@]}" 2>>"$LOG" | tee -a "$LOG"
    rc=${PIPESTATUS[0]}
  fi
  t1=$(date +%s); used=$((t1-t0)); [ "$used" -lt 1 ] && used=1
  if [ "$rc" -ne 0 ] || [ ! -f "$outbase.$first_fmt" ]; then
    say "${c_red}  ✗ 转写失败（代码 $rc），详见日志${c_off}"; failed=$((failed+1)); continue
  fi

  # 5) 中文整理：转简体、半角标点改全角（macOS 自带转换，不动时间轴）
  if [ "$SIMPLIFIED_CHINESE" = "yes" ] && { [ "$lang" = "zh" ] || [ "$lang" = "yue" ]; }; then
    files=(); for f in $FORMATS; do [ -f "$outbase.$f" ] && files+=("$outbase.$f"); done
    [ ${#files[@]} -gt 0 ] && osascript -l JavaScript "$APP_DIR/tools/to_simplified.js" "${files[@]}" 2>>"$LOG"
  fi

  printf '%s' "$MODE" > "$modef"

  if [ "$MOVE_DONE" = "yes" ]; then
    case "$src" in "$IN_ROOT"/*)
      donedir="$IN_ROOT/已完成${rel:+/$rel}"; mkdir -p "$donedir"; mv "$src" "$donedir/" ;;
    esac
  fi
  speed=$(awk "BEGIN{printf \"%.1f\", $secs/$used}")
  say "${c_grn}  ✓ 完成，用时 ${used} 秒（${speed} 倍速）→ 输出${rel:+/$rel}/$base.{${FORMATS// /,}}${c_off}"
  ok=$((ok+1))
done < "$LIST"

ALL=$(( $(date +%s) - START_ALL ))
say ""
say "${c_grn}========== 全部结束 ==========${c_off}"
say "成功 $ok 个 · 跳过 $skipped 个 · 失败 $failed 个 · 总用时 $((ALL/60))分$((ALL%60))秒"
[ "$failed" -gt 0 ] && say "${c_ylw}失败原因见日志：$LOG${c_off}"
exit 0
